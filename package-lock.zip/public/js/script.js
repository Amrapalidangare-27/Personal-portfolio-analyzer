document.addEventListener("DOMContentLoaded", () => {

    const loginForm = document.getElementById("loginForm");

    if (loginForm) {

        loginForm.addEventListener("submit", async (e) => {

            e.preventDefault();

            const email =
                document.getElementById("email").value.trim();

            const password =
                document.getElementById("password").value;

            try {

                const response = await fetch("/auth/login", {

                    method: "POST",

                    headers: {
                        "Content-Type": "application/json"
                    },

                    body: JSON.stringify({
                        email: email,
                        password: password
                    })

                });

                const data = await response.json();

                if (data.success) {

                    // Save logged-in user
                    localStorage.setItem(
                        "user",
                        JSON.stringify(data.user)
                    );

                    alert("Login successful! 🎉");

                    // Go to dashboard
                    window.location.href = "/dashboard.html";

                } else {

                    alert(data.message);

                }

            } catch (error) {

                console.error("Login error:", error);

                alert(
                    "Server se connection nahi ho raha."
                );

            }

        });

    }

});